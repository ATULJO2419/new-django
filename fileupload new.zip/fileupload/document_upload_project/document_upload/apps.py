from django.apps import AppConfig


class DocumentUploadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'document_upload'
