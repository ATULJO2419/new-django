# Bulk File Uploader Django Project
A simple django project that is used to upload bulk files to the database

## Setup this Project

### Clone this project
```
git clone https://github.com/Aashishkumar123/bulk-file-uploader-django
```

### Install following dependencies
```
pip install django pillow
```

### Run the server
```
python manage.py runserver
```
