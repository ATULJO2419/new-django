from django.urls import path
from .views import get_units,upload_document

urlpatterns = [
    path('upload/', upload_document, name='upload_document'),
    path('', upload_document, name='home'),
    path('get_units/',get_units, name='get_units'),

]
