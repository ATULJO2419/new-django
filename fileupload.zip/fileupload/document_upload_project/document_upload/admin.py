from django.contrib import admin
from .models import Station, Unit, Document

admin.site.register(Station)
admin.site.register(Unit)

class DocumentAdmin(admin.ModelAdmin):
    list_display = ('user', 'station', 'unit', 'upload_datetime', 'document_file')

admin.site.register(Document, DocumentAdmin)
