from django.contrib import admin
from .models import Station, Unit, Document

admin.site.register(Station)
admin.site.register(Unit)
admin.site.register(Document)
