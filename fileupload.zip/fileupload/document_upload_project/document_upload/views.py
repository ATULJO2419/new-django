from django.shortcuts import render
from .forms import DocumentForm
from .models import Station, Unit 
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

@login_required
def upload_document(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.instance
            document.user = request.user  
            form.save()
            return render(request, 'document_upload/success.html', {'document': document})
        else:
            # Form is not valid, handle errors
            return render(request, 'document_upload/upload.html', {'form': form, 'stations': Station.objects.all(), 'units': Unit.objects.all(), 'error': 'Form is not valid'})
    else:
        form = DocumentForm()

    stations = Station.objects.all()
    units = Unit.objects.all()

    return render(request, 'document_upload/upload.html', {'form': form, 'stations': stations, 'units': units})

def get_units(request):
    station_id = request.POST.get('station')

    if not station_id:
        return JsonResponse({ 'units': [] })

    units = Unit.objects.filter(station_id=station_id)
    unit_options = [{'id': unit.id, 'name': unit.name} for unit in units]

    return JsonResponse({ 'units': unit_options })


