from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('document/', include('document_upload.urls')),
    # Add the following line for the root path
    path('', include('document_upload.urls')),
]
